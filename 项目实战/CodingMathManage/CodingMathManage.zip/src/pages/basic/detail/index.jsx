import React from 'react';

export default class NewOrgnization extends React.Component {
  render() {
    return <p>机构列表</p>
  }
}
