export default {
  'exceptionand404.exception.back': '返回首頁',
  'exceptionand404.description.404': '抱歉，妳訪問的頁面不存在。',
};
