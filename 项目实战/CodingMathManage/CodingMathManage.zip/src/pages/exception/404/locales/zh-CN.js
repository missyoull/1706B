export default {
  'exceptionand404.exception.back': '返回首页',
  'exceptionand404.description.404': '抱歉，你访问的页面不存在。',
};
