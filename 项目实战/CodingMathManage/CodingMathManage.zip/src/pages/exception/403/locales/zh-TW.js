export default {
  'exceptionand403.exception.back': '返回首頁',
  'exceptionand403.description.403': '抱歉，妳無權訪問該頁面。',
};
