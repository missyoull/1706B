export default {
  'exceptionand403.exception.back': 'Back to home',
  'exceptionand403.description.403': "Sorry, you don't have access to this page.",
};
