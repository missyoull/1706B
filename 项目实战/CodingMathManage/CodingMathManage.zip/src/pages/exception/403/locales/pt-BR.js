export default {
  'exceptionand403.exception.back': 'Voltar para Início',
  'exceptionand403.description.403': 'Desculpe, você não tem acesso a esta página.',
};
