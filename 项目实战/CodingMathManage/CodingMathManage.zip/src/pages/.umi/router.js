import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import RendererWrapper0 from 'D:/web/project/1706B/CodingMathManage/src/pages/.umi/LocaleWrapper.jsx';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: require('../../layouts/BlankLayout').default,
    routes: [
      {
        path: '/user',
        component: require('../../layouts/UserLayout').default,
        routes: [
          {
            path: '/user',
            redirect: '/user/login',
            exact: true,
          },
          {
            name: 'login',
            icon: 'smile',
            path: '/user/login',
            component: require('../user/login').default,
            exact: true,
          },
          {
            name: 'register-result',
            icon: 'smile',
            path: '/user/register-result',
            component: require('../user/register-result').default,
            exact: true,
          },
          {
            name: 'register',
            icon: 'smile',
            path: '/user/register',
            component: require('../user/register').default,
            exact: true,
          },
          {
            component: require('../404').default,
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        path: '/',
        component: require('../../layouts/BasicLayout').default,
        Routes: [require('../Authorized').default],
        routes: [
          {
            path: '/dashboard',
            name: 'dashboard',
            icon: 'dashboard',
            routes: [
              {
                name: 'analysis',
                icon: 'smile',
                path: '/dashboard/analysis',
                component: require('../dashboard/analysis').default,
                exact: true,
              },
              {
                name: 'monitor',
                icon: 'smile',
                path: '/dashboard/monitor',
                component: require('../dashboard/monitor').default,
                exact: true,
              },
              {
                name: 'workplace',
                icon: 'smile',
                path: '/dashboard/workplace',
                component: require('../dashboard/workplace').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'orgnization',
            icon: 'dashboard',
            path: '/orgnization',
            routes: [
              {
                name: 'index',
                path: '/orgnization/index',
                component: require('../orgnization/index').default,
                exact: true,
              },
              {
                name: 'new',
                path: '/orgnization/new',
                component: require('../orgnization/new').default,
                exact: true,
              },
              {
                name: 'detail',
                hideInMenu: true,
                path: '/orgnization/detail/:id?',
                component: require('../orgnization/detail').default,
                exact: true,
              },
              {
                name: 'edit',
                hideInMenu: true,
                path: '/orgnization/edit/:id?',
                component: require('../orgnization/edit').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'teacher',
            icon: 'form',
            path: '/teacher',
            routes: [
              {
                name: 'project',
                path: '/teacher/project',
                routes: [
                  {
                    name: 'index',
                    path: '/teacher/project/index',
                    component: require('../teacher/project/index').default,
                    exact: true,
                  },
                  {
                    name: 'new',
                    path: '/teacher/project/new',
                    component: require('../teacher/project/new').default,
                    exact: true,
                  },
                  {
                    name: 'detail',
                    hideInMenu: true,
                    path: '/teacher/project/detail/:id?',
                    component: require('../teacher/project/detail').default,
                    exact: true,
                  },
                  {
                    name: 'edit',
                    hideInMenu: true,
                    path: '/teacher/project/:id?',
                    component: require('../teacher/project/edit').default,
                    exact: true,
                  },
                  {
                    component: () =>
                      React.createElement(
                        require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                          .default,
                        { pagesPath: 'src/pages', hasRoutesInConfig: true },
                      ),
                  },
                ],
              },
              {
                name: 'class',
                path: '/teacher/class',
                routes: [
                  {
                    name: 'index',
                    path: '/teacher/class/index',
                    component: require('../teacher/class/index').default,
                    exact: true,
                  },
                  {
                    name: 'new',
                    path: '/teacher/class/new',
                    component: require('../teacher/class/new').default,
                    exact: true,
                  },
                  {
                    name: 'detail',
                    hideInMenu: true,
                    path: '/teacher/class/detail/:id?',
                    component: require('../teacher/class/detail').default,
                    exact: true,
                  },
                  {
                    name: 'edit',
                    hideInMenu: true,
                    path: '/teacher/class/eidt/:id?',
                    component: require('../teacher/class/edit').default,
                    exact: true,
                  },
                  {
                    component: () =>
                      React.createElement(
                        require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                          .default,
                        { pagesPath: 'src/pages', hasRoutesInConfig: true },
                      ),
                  },
                ],
              },
              {
                name: 'student',
                path: '/teacher/student',
                routes: [
                  {
                    name: 'index',
                    path: '/teacher/student/index',
                    component: require('../teacher/student/index').default,
                    exact: true,
                  },
                  {
                    name: 'new',
                    path: '/teacher/student/new',
                    component: require('../teacher/student/new').default,
                    exact: true,
                  },
                  {
                    name: 'detail',
                    hideInMenu: true,
                    path: '/teacher/student/detail/:id?',
                    component: require('../teacher/student/detail').default,
                    exact: true,
                  },
                  {
                    name: 'edit',
                    hideInMenu: true,
                    path: '/teacher/student/edit/:id?',
                    component: require('../teacher/student/edit').default,
                    exact: true,
                  },
                  {
                    component: () =>
                      React.createElement(
                        require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                          .default,
                        { pagesPath: 'src/pages', hasRoutesInConfig: true },
                      ),
                  },
                ],
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'recruit',
            icon: 'table',
            path: '/recruit',
            routes: [
              {
                name: 'index',
                path: '/recruit/index',
                component: require('../recruit/index').default,
                exact: true,
              },
              {
                name: 'new',
                hideInMenu: true,
                path: '/recruit/new',
                component: require('../recruit/new').default,
                exact: true,
              },
              {
                name: 'detail',
                hideInMenu: true,
                path: '/recruit/detail/:id?',
                component: require('../recruit/detail').default,
                exact: true,
              },
              {
                name: 'edit',
                hideInMenu: true,
                path: '/recruit/edit/:id?',
                component: require('../recruit/edit').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'operate',
            icon: 'profile',
            path: '/operate',
            routes: [
              {
                name: 'banner',
                path: '/operate/banner',
                routes: [
                  {
                    name: 'index',
                    path: '/operate/banner/index',
                    component: require('../operate/banner/index').default,
                    exact: true,
                  },
                  {
                    name: 'new',
                    path: '/operate/banner/new',
                    component: require('../operate/banner/new').default,
                    exact: true,
                  },
                  {
                    component: () =>
                      React.createElement(
                        require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                          .default,
                        { pagesPath: 'src/pages', hasRoutesInConfig: true },
                      ),
                  },
                ],
              },
              {
                name: 'pc',
                path: '/operate/pc',
                routes: [
                  {
                    name: 'index',
                    path: '/operate/pc/index',
                    hideInMenu: true,
                    component: require('../operate/pc/index').default,
                    exact: true,
                  },
                  {
                    name: 'new',
                    path: '/operate/pc/new',
                    hideInMenu: true,
                    component: require('../operate/pc/new').default,
                    exact: true,
                  },
                  {
                    component: () =>
                      React.createElement(
                        require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                          .default,
                        { pagesPath: 'src/pages', hasRoutesInConfig: true },
                      ),
                  },
                ],
              },
              {
                component: () =>
                  React.createElement(
                    require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            name: 'basic',
            icon: 'highlight',
            path: '/basic',
            exact: true,
          },
          {
            name: 'permission',
            icon: 'check-circle-o',
            path: '/permission',
            exact: true,
          },
          {
            path: '/',
            redirect: '/dashboard/analysis',
            authority: ['admin', 'user'],
            exact: true,
          },
          {
            component: require('../404').default,
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        component: () =>
          React.createElement(
            require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: () =>
      React.createElement(
        require('D:/web/project/1706B/CodingMathManage/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
