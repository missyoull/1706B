import dva from 'dva';
import { Component } from 'react';
import createLoading from 'dva-loading';
import history from '@tmp/history';

let app = null;

export function _onCreate() {
  const plugins = require('umi/_runtimePlugin');
  const runtimeDva = plugins.mergeConfig('dva');
  app = dva({
    history,
    
    ...(runtimeDva.config || {}),
    ...(window.g_useSSR ? { initialState: window.g_initialData } : {}),
  });
  
  app.use(createLoading());
  (runtimeDva.plugins || []).forEach(plugin => {
    app.use(plugin);
  });
  
  app.model({ namespace: 'global', ...(require('D:/web/project/1706B/CodingMathManage/src/models/global.js').default) });
app.model({ namespace: 'login', ...(require('D:/web/project/1706B/CodingMathManage/src/models/login.js').default) });
app.model({ namespace: 'setting', ...(require('D:/web/project/1706B/CodingMathManage/src/models/setting.js').default) });
app.model({ namespace: 'user', ...(require('D:/web/project/1706B/CodingMathManage/src/models/user.js').default) });
app.model({ namespace: 'model', ...(require('D:/web/project/1706B/CodingMathManage/src/pages/user/login/model.js').default) });
app.model({ namespace: 'model', ...(require('D:/web/project/1706B/CodingMathManage/src/pages/user/register/model.js').default) });
app.model({ namespace: 'model', ...(require('D:/web/project/1706B/CodingMathManage/src/pages/dashboard/analysis/model.jsx').default) });
app.model({ namespace: 'model', ...(require('D:/web/project/1706B/CodingMathManage/src/pages/dashboard/monitor/model.js').default) });
app.model({ namespace: 'model', ...(require('D:/web/project/1706B/CodingMathManage/src/pages/dashboard/workplace/model.js').default) });
  return app;
}

export function getApp() {
  return app;
}

export class _DvaContainer extends Component {
  render() {
    const app = getApp();
    app.router(() => this.props.children);
    return app.start()();
  }
}
