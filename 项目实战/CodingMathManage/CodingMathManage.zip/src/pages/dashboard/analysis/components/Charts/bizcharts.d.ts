import * as BizChart from 'bizcharts';

export = BizChart;
