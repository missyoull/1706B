export default {
  'resultandfail.error.title': '提交失败',
  'resultandfail.error.description': '请核对并修改以下信息后，再重新提交。',
  'resultandfail.error.hint-title': '您提交的内容有如下错误：',
  'resultandfail.error.hint-text1': '您的账户已被冻结',
  'resultandfail.error.hint-btn1': '立即解冻',
  'resultandfail.error.hint-text2': '您的账户还不具备申请资格',
  'resultandfail.error.hint-btn2': '立即升级',
  'resultandfail.error.btn-text': '返回修改',
};
