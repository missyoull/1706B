export default {
  'resultandfail.error.title': '提交失敗',
  'resultandfail.error.description': '請核對並修改以下信息後，再重新提交。',
  'resultandfail.error.hint-title': '您提交的內容有如下錯誤：',
  'resultandfail.error.hint-text1': '您的賬戶已被凍結',
  'resultandfail.error.hint-btn1': '立即解凍',
  'resultandfail.error.hint-text2': '您的賬戶還不具備申請資格',
  'resultandfail.error.hint-btn2': '立即升級',
  'resultandfail.error.btn-text': '返回修改',
};
