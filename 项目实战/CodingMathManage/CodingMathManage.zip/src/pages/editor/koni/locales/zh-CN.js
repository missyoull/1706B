export default {
  'editorandkoni.description': '拓扑结构图是指由网络节点设备和通信介质构成的网络结构图',
};
