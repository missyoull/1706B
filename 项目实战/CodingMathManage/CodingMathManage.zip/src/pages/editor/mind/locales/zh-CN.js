export default {
  'editorandmind.description':
    '脑图是表达发散性思维的有效图形思维工具 ，它简单却又很有效，是一种实用性的思维工具',
};
